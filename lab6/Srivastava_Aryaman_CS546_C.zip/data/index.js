// This file should import both data files and export them as shown in the lecture code
import * as products from './products.js';
import * as reviews from './reviews.js';

export const productData = products;
export const reviewData = reviews;